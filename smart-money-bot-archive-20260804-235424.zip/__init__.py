# Package for trading strategies
